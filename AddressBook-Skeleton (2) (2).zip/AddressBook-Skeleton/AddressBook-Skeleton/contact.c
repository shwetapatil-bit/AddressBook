#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"

int validateName(char name[]) {
    int len = strlen(name);
    if (len == 0 || len > 30) return 0;
    for (int i = 0; i < len; i++) {
        if (!isalpha(name[i]) && name[i] != ' ' && name[i] != '.')
            return 0;
    }
    return 1;
}

int validatePhone(char phone[]) {
    if (strlen(phone) != 10) return 0;
    for (int i = 0; i < 10; i++)
        if (!isdigit(phone[i])) return 0;
    return 1;
}

int validateEmail(char email[]) {
    int len = strlen(email);
    if (len == 0 || len > 50) return 0;

    char *at = strchr(email, '@');
    char *dot = strrchr(email, '.');

    if (!at || !dot) return 0;
    if (at == email) return 0;
    if (dot < at) return 0;
    if (dot == email + len - 1) return 0;
    return 1;
}

int isDuplicate(AddressBook *book, char name[], char phone[]) {
    for (int i = 0; i < book->contactCount; i++) {
        if (strcmp(book->contacts[i].name, name) == 0 ||
            strcmp(book->contacts[i].phone, phone) == 0)
            return 1;
    }
    return 0;
}

// ---------------------- File Handling ----------------------

void loadContactsFromCSV(AddressBook *book) {
    FILE *file = fopen("contact.csv", "r");
    if (!file) {
        printf("No existing CSV file found. Starting fresh.\n");
        book->contactCount = 0;
        return;
    }

    char line[200];
    book->contactCount = 0;
    fgets(line, sizeof(line), file); // skip header

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0;
        char *token = strtok(line, ",");
        if (!token) continue;
        strcpy(book->contacts[book->contactCount].name, token);

        token = strtok(NULL, ",");
        if (!token) continue;
        strcpy(book->contacts[book->contactCount].phone, token);

        token = strtok(NULL, ",");
        if (!token) continue;
        strcpy(book->contacts[book->contactCount].email, token);

        book->contactCount++;
    }

    fclose(file);
    printf("Contacts loaded successfully (%d contacts).\n", book->contactCount);
}

void saveContactsToCSV(AddressBook *book) {
    FILE *file = fopen("contact.csv", "w");
    if (!file) {
        printf("Error saving contacts!\n");
        return;
    }

    fprintf(file, "Name,Phone,Email\n");
    for (int i = 0; i < book->contactCount; i++) {
        fprintf(file, "%s,%s,%s\n",
                book->contacts[i].name,
                book->contacts[i].phone,
                book->contacts[i].email);
    }
    fclose(file);
    printf("Contacts saved successfully!\n");
}

// ---------------------- Core CRUD ----------------------

int createContact(AddressBook *book) {
    if (book->contactCount >= MAX_CONTACTS) {
        printf("Address book full!\n");
        return 0;
    }

    char name[50], phone[30], email[80];

    printf("Enter Name: ");
    scanf(" %[^\n]", name);
    if (!validateName(name)) {
        printf("Invalid name! Only letters, spaces and '.' allowed (max 30 chars)\n");
        return 0;
    }

    printf("Enter Phone: ");
    scanf("%s", phone);
    if (!validatePhone(phone)) {
        printf("Invalid phone! Must be exactly 10 digits.\n");
        return 0;
    }
    printf("Enter Email: ");
    scanf("%s", email);
    if (!validateEmail(email)) {
        printf("Invalid email format!\n");
        return 0;
    }

    if (isDuplicate(book, name, phone)) {
        printf("Contact already exists!\n");
        return 0;
    }

    strcpy(book->contacts[book->contactCount].name, name);
    strcpy(book->contacts[book->contactCount].phone, phone);
    strcpy(book->contacts[book->contactCount].email, email);
    book->contactCount++;

    printf("✅ Contact added successfully!\n");
    return 1;
}


void listContact(AddressBook *book) {
    if (book->contactCount == 0) {
        printf("No contacts available.\n");
        return;
    }

    printf("\n----- Contact List -----\n");
    for (int i = 0; i < book->contactCount; i++) {
        printf("%d. %s | %s | %s\n",
               i + 1,
               book->contacts[i].name,
               book->contacts[i].phone,
               book->contacts[i].email);
    }
    printf("------------------------\n");
}

void toLowerCase(char *str) {
    for (int i = 0; str[i]; i++)
        str[i] = tolower(str[i]);
}

void searchContact(AddressBook *book) {
    if (book->contactCount == 0) {
        printf("No contacts available.\n");
        return;
    }

    char keyword[50];
    printf("Enter part of name to search: ");
    getchar();
    fgets(keyword, sizeof(keyword), stdin);
    keyword[strcspn(keyword, "\n")] = '\0';

    char keywordLower[50];
    strcpy(keywordLower, keyword);
    toLowerCase(keywordLower);

    int found = 0;
    for (int i = 0; i < book->contactCount; i++) {
        char nameLower[50];
        strcpy(nameLower, book->contacts[i].name);
        toLowerCase(nameLower);

        if (strstr(nameLower, keywordLower)) {
            printf("%d. %s | %s | %s\n",
                   i + 1,
                   book->contacts[i].name,
                   book->contacts[i].phone,
                   book->contacts[i].email);
            found = 1;
        }
    }

    if (!found)
        printf("No contact found containing \"%s\".\n", keyword);
}
void editContact(AddressBook *book) {
    char name[50];
    printf("Enter contact name to edit: ");
    scanf(" %[^\n]", name);

    for (int i = 0; i < book->contactCount; i++) {
        if (strcmp(book->contacts[i].name, name) == 0) {
            char newName[50], newPhone[20], newEmail[50];

            printf("Enter new Name: ");
            scanf(" %[^\n]", newName);
            if (!validateName(newName)) {
                printf("Invalid name!\n");
                return;
            }

            printf("Enter new Phone: ");
            scanf("%s", newPhone);
            if (!validatePhone(newPhone)) {
                printf("Invalid phone number!\n");
                return;
            }

            printf("Enter new Email: ");
            scanf("%s", newEmail);
            if (!validateEmail(newEmail)) {
                printf("Invalid email!\n");
                return;
            }

            strcpy(book->contacts[i].name, newName);
            strcpy(book->contacts[i].phone, newPhone);
            strcpy(book->contacts[i].email, newEmail);

            printf("✅ Contact updated successfully!\n");
            return;
        }
    }
    printf("Contact not found!\n");
}

int deleteContact(AddressBook *book) {
    if (book->contactCount == 0) {
        printf("No contacts to delete.\n");
        return 0;
    }

    listContact(book);
    char name[50];
    printf("Enter name to delete: ");
    getchar();
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = '\0';

    for (int i = 0; i < book->contactCount; i++) {
        if (strcmp(book->contacts[i].name, name) == 0) {
            printf("Deleting contact at index %d:\n", i + 1);
            printf("   Name : %s\n", book->contacts[i].name);
            printf("   Phone: %s\n", book->contacts[i].phone);
            printf("   Email: %s\n", book->contacts[i].email);

            for (int j = i; j < book->contactCount - 1; j++) {
                book->contacts[j] = book->contacts[j + 1];
            }
            book->contactCount--;

            printf("Contact deleted successfully!\n");
            return 1;
        }
    }

    printf("Contact not found!\n");
    return 0;
}