#include<stdio.h>
#include"contact.h"

int main() {
    AddressBook book;
    book.contactCount = 0;
    loadContactsFromCSV(&book);


    int choice;

    do {
        printf("\n===== ADDRESS BOOK =====\n");
        printf("1. Add Contact\n");
        printf("2. List Contacts\n");
        printf("3. Search Contact\n");
        printf("4. Edit Contact\n");
        printf("5. Delete Contact\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input! Please enter a number.\n");
            while (getchar() != '\n'); // Clear buffer
            choice = 0;
            continue;
        }

        switch (choice) {
            case 1:
                if (createContact(&book))
                    saveContactsToCSV(&book);
                break;
            case 2:
                listContact(&book);
                break;
            case 3:
                searchContact(&book);
                break;
            case 4:
                editContact(&book);
                saveContactsToCSV(&book);
                break;
            case 5:
                deleteContact(&book);
                saveContactsToCSV(&book);
                break;
            case 6:
                printf("Thank you, bye!\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 6);

    return 0;
}