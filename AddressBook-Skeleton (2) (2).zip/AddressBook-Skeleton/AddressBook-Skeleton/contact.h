#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {
    Contact contacts[MAX_CONTACTS];
    int contactCount;
} AddressBook;

int createContact(AddressBook *book);
void listContact(AddressBook *book);
void searchContact(AddressBook *book);
void editContact(AddressBook *book);
int deleteContact(AddressBook *book);
void saveContactsToCSV(AddressBook *book);
void loadContactsFromCSV(AddressBook *book);
void loadDummyContacts(AddressBook *book);
#endif
